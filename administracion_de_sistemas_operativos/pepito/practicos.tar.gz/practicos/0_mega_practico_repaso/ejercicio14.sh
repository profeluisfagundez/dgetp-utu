sudo systemctl stop mariadb.service
sudo systemctl restart mariadb.service
sudo systemctl start mariadb.service
sudo systemctl enable mariadb.service

Resumen de los comandos:

Detener el servicio: sudo systemctl stop mariadb.service
Reiniciar el servicio: sudo systemctl restart mariadb.service
Iniciar el servicio: sudo systemctl start mariadb.service
Habilitar el arranque automático: sudo systemctl enable mariadb.service