#!/bin/bash
find /usr/bin -type f -perm /111 -ls