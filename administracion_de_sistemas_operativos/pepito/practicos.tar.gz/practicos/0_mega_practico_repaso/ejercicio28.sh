find ~/ -type f -name "pas*" ! -name "*swd"
