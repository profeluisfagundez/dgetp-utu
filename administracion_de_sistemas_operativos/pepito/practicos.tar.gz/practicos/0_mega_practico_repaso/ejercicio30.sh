#!/bin/bash
find / -type f -size -5M