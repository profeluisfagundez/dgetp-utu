mkdir -p mega_practico/{archivos/{archivos_importantes,archivos_no_importantes},practicos,teoricos}
touch mega_practico/practicos/practico{1..10}.txt
touch mega_practico/teoricos/teorico{1..5}.odp
tree mega_practico