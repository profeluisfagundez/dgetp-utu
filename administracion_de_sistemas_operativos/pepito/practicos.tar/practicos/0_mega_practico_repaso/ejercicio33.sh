#!/bin/bash
find /usr/bin -type f -executable | sort -r