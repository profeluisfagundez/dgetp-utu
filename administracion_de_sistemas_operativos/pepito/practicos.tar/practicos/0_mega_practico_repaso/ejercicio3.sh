#!/bin/bash
clear
cal
sleep 10
echo "Usuario: $USER"
echo "Home: $HOME"
echo "Hora actual: $(date '+%Y-%m-%d-%H:%M:%S')"
sleep 5
clear