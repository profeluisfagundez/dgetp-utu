#!/bin/bash
chmod u+x *.sh
