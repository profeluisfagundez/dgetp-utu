find . -type d -iname 'imagen*'
find . -type d -iregex '.*/[iI]m[aá]genes?'
