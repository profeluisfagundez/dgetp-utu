#!/bin/bash
find / -type f -name ".*" 2>/dev/null | wc -l